#pragma once
#include "Config.h"

struct Alarms {
  uint8_t overtemp=0, airflowFail=0, sensorFail=0, programFail=0, badPosture=0;
  void clear(){ overtemp=airflowFail=sensorFail=programFail=badPosture=0; }
  bool any() const { return overtemp||airflowFail||sensorFail||programFail||badPosture; }
};
