#pragma once
#include "Config.h"
#include <esp_task_wdt.h>

class Watchdog {
public:
  // No inicializamos; Arduino core ya lo hizo.
  static void begin(uint32_t timeout_ms = 10000, bool panic = false){
#if ESP_IDF_VERSION_MAJOR >= 5
    // Reconfigura si está disponible; si no, ignora el error
    esp_task_wdt_config_t cfg = { .timeout_ms = timeout_ms, .trigger_panic = panic };
    (void)esp_task_wdt_reconfigure(&cfg);
#else
    // En IDF <5 podrías hacer init si no estaba; aquí lo omitimos para evitar logs
    (void)timeout_ms; (void)panic;
#endif
    // NO hacemos esp_task_wdt_add(NULL) aquí para no tocar loopTask por accidente.
  }

  // Llama esto al inicio de setup() para quitar loopTask del WDT
  static void detachFromLoop(){
    // Estamos ejecutando en loopTask → borramos esta tarea del TWDT
    esp_task_wdt_delete(NULL);
  }

  // Úsalo dentro de cada tarea que SÍ quieras vigilar
  static void addThisTask(){ esp_task_wdt_add(NULL); }

  static void feed(){ esp_task_wdt_reset(); }
};
