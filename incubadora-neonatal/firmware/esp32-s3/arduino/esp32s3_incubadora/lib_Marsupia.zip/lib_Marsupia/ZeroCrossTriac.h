#pragma once
#include "Config.h"
#include <Arduino.h>

// ISR C ultraminimal (solo setea un flag)
extern "C" void IRAM_ATTR zc_isr(void);

class ZeroCrossTriac {
  // Estado compartido (en DRAM)
  static inline portMUX_TYPE mux_ = portMUX_INITIALIZER_UNLOCKED;
  static inline volatile uint8_t duty_ = 0;   // 0..100
  static inline volatile bool skip_ = true;

  // Flag de cruce (lo único que toca la ISR)
  static inline volatile bool zcFlag_ = false;

  static void triacTask(void*){
    pinMode(TRIAC_PIN, OUTPUT);
    digitalWrite(TRIAC_PIN, LOW);

    for(;;){
      // Espera al flag del cruce (no usamos notificaciones ISR)
      while (!zcFlag_) {
        // 120 cruces/s → basta con yield corto para no bloquear CPU
        vTaskDelay(pdMS_TO_TICKS(1));
      }
      // Consumir el evento
      zcFlag_ = false;

      // Tomamos timestamp AQUÍ (seguro)
      uint32_t zero_us = micros();

      // Copias locales de control
      uint8_t d; bool sk;
      portENTER_CRITICAL(&mux_); d=duty_; sk=skip_; portEXIT_CRITICAL(&mux_);
      if (sk) continue;

      // duty 0..100 → delay 8333..0 us
      uint32_t delayUS = (uint32_t)((HALF_CYCLE_US * (100 - (uint32_t)d)) / 100);
      uint32_t target = zero_us + delayUS;

      // Espera activa corta al punto de disparo
      while ((int32_t)(micros() - (int32_t)target) < 0) { /* busy wait */ }

      // Disparo TRIAC
      digitalWrite(TRIAC_PIN, HIGH);
      delayMicroseconds(500);
      digitalWrite(TRIAC_PIN, LOW);
    }
  }

public:
  static void begin(){
    xTaskCreatePinnedToCore(triacTask, "triacTask",
                            2048, nullptr, 2, nullptr, 0);
    delay(50);
    // ISR C minimal: solo levanta el flag
    attachInterrupt(ZC_PIN, zc_isr, RISING);
  }

  static void setDuty(uint8_t d){
    if (d > 100) d = 100;
    portENTER_CRITICAL(&mux_);
    duty_ = d;
    skip_ = (d == 0);
    portEXIT_CRITICAL(&mux_);
  }

  // Hook que usa la ISR: SÓLO levantar el flag, sin llamadas
  static inline void IRAM_ATTR isrFlagRaise(){
    zcFlag_ = true;
  }
};

// Definición de la ISR C: no llama a nada, solo flag
extern "C" void IRAM_ATTR zc_isr(void) {
  ZeroCrossTriac::isrFlagRaise();
}
