#pragma once
#include <Arduino.h>
#include "Config.h"

inline float ntcReadTempC(){
  int raw = analogRead(NTC_PIN);
  raw = constrain(raw, 1, 4094);
  float v = (float)raw / 4095.0f;
  float r_ntc = (NTC_R_SERIES * v) / (1.0f - v);
  float invT = (1.0f/NTC_T0_K) + (1.0f/NTC_BETA) * logf(r_ntc / NTC_R0);
  float tK = 1.0f / invT;
  return tK - 273.15f;
}
