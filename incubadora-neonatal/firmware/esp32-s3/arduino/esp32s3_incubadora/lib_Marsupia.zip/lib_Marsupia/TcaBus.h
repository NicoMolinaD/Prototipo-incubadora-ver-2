#pragma once
#include <Wire.h>
#include "Config.h"

struct TcaBus {
  static void begin() {
    Wire.begin(I2C_SDA, I2C_SCL);
    Wire.setClock(400000);
  }
  static void select(uint8_t ch) {
    if (ch>7) return;
    Wire.beginTransmission(TCA_ADDR);
    Wire.write(1 << ch);
    Wire.endTransmission();
  }
};
