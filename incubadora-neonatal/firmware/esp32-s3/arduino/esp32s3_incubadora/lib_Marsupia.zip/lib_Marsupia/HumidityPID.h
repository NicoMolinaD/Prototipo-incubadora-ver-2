#pragma once
#include <Arduino.h>
#include "driver/ledc.h"
#include "Config.h"

class HumidityPID {
public:
  float Kp = 2.0f;
  float Ki = 0.10f;
  float Kd = 0.0f;
  uint32_t Ts_ms = 500;

  HumidityPID() {}
  void begin() {
    // Timer LEDC: 20 kHz, 8 bits (LOW_SPEED para S3)
    ledc_timer_config_t timer = {
      .speed_mode       = LEDC_LOW_SPEED_MODE,
      .duty_resolution  = LEDC_TIMER_8_BIT,
      .timer_num        = LEDC_TIMER_0,
      .freq_hz          = 20000,
      .clk_cfg          = LEDC_AUTO_CLK
    };
    ledc_timer_config(&timer);

    // Canal LEDC en HUM_PWM_PIN
    ledc_channel_config_t ch = {
      .gpio_num   = HUM_PWM_PIN,
      .speed_mode = LEDC_LOW_SPEED_MODE,
      .channel    = LEDC_CHANNEL_0,
      .intr_type  = LEDC_INTR_DISABLE,
      .timer_sel  = LEDC_TIMER_0,
      .duty       = 0,
      .hpoint     = 0
    };
    ledc_channel_config(&ch);

    setDutyPct(0);
    lastMs_ = millis();
  }

  void setSetpoint(float spRH) { sp_ = spRH; }
  float getSetpoint() const { return sp_; }

  float update(float rhMeas) {
    uint32_t now = millis();
    if ((now - lastMs_) < Ts_ms) return outPct_;
    lastMs_ = now;

    if (isnan(rhMeas) || isnan(sp_)) return outPct_;

    float e = sp_ - rhMeas;
    float uP = Kp * e;

    // integral con anti-windup
    integ_ += Ki * e;
    integ_ = constrain(integ_, outMin_, outMax_);

    float dMeas = (prevMeasInit_ ? (rhMeas - prevMeas_) : 0.0f);
    prevMeas_ = rhMeas; prevMeasInit_ = true;
    float uD = -Kd * dMeas;

    float u = uP + integ_ + uD;
    u = constrain(u, outMin_, outMax_);
    outPct_ = u;

    setDutyPct((int)roundf(outPct_));
    return outPct_;
  }

  void setTunings(float kp, float ki, float kd) { Kp=kp; Ki=ki; Kd=kd; }
  void setSampleTime(uint32_t Ts_new) { Ts_ms=Ts_new; }
  void setOutputLimits(float minPct, float maxPct) {
    outMin_ = min(minPct, maxPct); outMax_ = max(minPct, maxPct);
    integ_  = constrain(integ_, outMin_, outMax_);
  }

private:
  float sp_ = 55.0f;
  float outPct_ = 0.0f;
  float integ_ = 0.0f;
  float outMin_ = 0.0f, outMax_ = 100.0f;
  float prevMeas_ = 0.0f; bool prevMeasInit_ = false;
  uint32_t lastMs_ = 0;

  void setDutyPct(int pct) {
    pct = constrain(pct, 0, 100);
    int duty = map(pct, 0, 100, 0, 255); // 8-bit
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
  }
};
