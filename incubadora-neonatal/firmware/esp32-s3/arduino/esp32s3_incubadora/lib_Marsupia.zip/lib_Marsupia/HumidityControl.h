#pragma once
#include <Arduino.h>
#include "driver/ledc.h"
#include "Config.h"

// Control P (no usado por defecto). Compatible S3 (sin ledcAttachPin).
class HumidityControl {
public:
  void begin(){
    ledc_timer_config_t timer = {
      .speed_mode       = LEDC_LOW_SPEED_MODE,
      .duty_resolution  = LEDC_TIMER_10_BIT,
      .timer_num        = LEDC_TIMER_1,
      .freq_hz          = 1000,
      .clk_cfg          = LEDC_AUTO_CLK
    };
    ledc_timer_config(&timer);

    ledc_channel_config_t ch = {
      .gpio_num   = HUM_PWM_PIN,
      .speed_mode = LEDC_LOW_SPEED_MODE,
      .channel    = LEDC_CHANNEL_1,
      .intr_type  = LEDC_INTR_DISABLE,
      .timer_sel  = LEDC_TIMER_1,
      .duty       = 0,
      .hpoint     = 0
    };
    ledc_channel_config(&ch);
    setDutyPct(0);
  }

  void setDutyPct(int pct){
    pct = constrain(pct, 0, 100);
    int duty = map(pct, 0, 100, 0, 1023); // 10-bit
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1);
  }

  void control(float spRH, float rhMeas){
    if (isnan(spRH) || isnan(rhMeas)) { setDutyPct(0); return; }
    float e = spRH - rhMeas;
    int pct = (int)roundf(4.0f * e);
    setDutyPct(pct);
  }
};
