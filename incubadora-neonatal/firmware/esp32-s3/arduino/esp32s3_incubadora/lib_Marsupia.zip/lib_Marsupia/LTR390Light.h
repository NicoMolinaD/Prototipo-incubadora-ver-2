#pragma once
#include "TcaBus.h"
#include <Adafruit_LTR390.h>

class LTR390Muxed {
  Adafruit_LTR390 ltr_;
  uint8_t ch_;
public:
  LTR390Muxed(uint8_t ch=CH_LTR390): ch_(ch) {}
  bool begin() {
    TcaBus::select(ch_);
    if (!ltr_.begin()) return false;
    ltr_.setMode(LTR390_MODE_ALS);
    ltr_.setGain(LTR390_GAIN_3);
    ltr_.setResolution(LTR390_RESOLUTION_18BIT);
    return true;
  }
  bool readALS(uint32_t &raw, float &lux) {
    TcaBus::select(ch_);
    raw = ltr_.readALS();
    lux = (float)raw * 0.6f / 1000.0f; // ajusta por calibración
    return true;
  }
};
