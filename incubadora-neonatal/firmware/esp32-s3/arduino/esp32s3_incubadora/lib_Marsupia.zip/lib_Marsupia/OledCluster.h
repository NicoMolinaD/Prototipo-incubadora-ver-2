#pragma once
#include <Adafruit_SH110X.h>
#include <Adafruit_SSD1306.h>
#include "TcaBus.h"

// Limpia bordes del SH1106 (evita la raya lateral)
inline void sh1106WipeEdges(Adafruit_SH1106G &oled){
  oled.drawFastVLine(0,   0, 64, SH110X_BLACK);
  oled.drawFastVLine(127, 0, 64, SH110X_BLACK);
}

// =============================
// Pantalla A: Temperaturas
// =============================
inline void drawOledA(Adafruit_SH1106G &oledA, uint8_t ch, float t_air_avg, float t_skin){
  TcaBus::selectSettle(ch);
  oledA.clearDisplay();
  oledA.setTextColor(SH110X_WHITE);

  oledA.setTextSize(1);
  oledA.setCursor(0, 0);
  oledA.println(F("TEMPERATURE"));

  // Temperatura de aire
  oledA.setCursor(0, 20);
  oledA.setTextSize(2);
  oledA.setCursor(36, 14);
  if (isnan(t_air_avg)) oledA.print(F("--.-"));
  else { char b[8]; snprintf(b,8,"%.1f", t_air_avg); oledA.print(b); }
  oledA.setTextSize(1); oledA.print(" C");

  // Temperatura de piel
  oledA.setCursor(0, 48);
  oledA.setTextSize(2);
  oledA.setCursor(56, 42);
  if (isnan(t_skin)) oledA.print(F("--.-"));
  else { char b[8]; snprintf(b,8,"%.1f", t_skin); oledA.print(b); }
  oledA.setTextSize(1); oledA.print(" C");

  sh1106WipeEdges(oledA);
  oledA.display();
}

// =============================
// Pantalla B: Humedad y peso
// =============================
inline void drawOledB(Adafruit_SH1106G &oledB, uint8_t ch, float rh_avg, float kg){
  TcaBus::selectSettle(ch);
  oledB.clearDisplay();
  oledB.setTextColor(SH110X_WHITE);

  oledB.setTextSize(1);
  oledB.setCursor(0, 0);
  oledB.println(F("HUMIDITY / WEIGHT"));

  // Humedad
  oledB.setCursor(0, 20);
  oledB.setTextSize(2);
  oledB.setCursor(36, 14);
  if (isnan(rh_avg)) oledB.print(F("--.-"));
  else { char b[8]; snprintf(b,8,"%.1f", rh_avg); oledB.print(b); }
  oledB.setTextSize(1); oledB.print(" %");

  // Peso
  oledB.setCursor(0, 48);
  oledB.setTextSize(2);
  oledB.setCursor(72, 42);
  if (isnan(kg)) oledB.print(F("--.--"));
  else { char b[8]; snprintf(b,8,"%.2f", kg); oledB.print(b); }
  oledB.setTextSize(1); oledB.print(" kg");

  sh1106WipeEdges(oledB);
  oledB.display();
}

// =============================
// Pantalla C: Setpoints
// =============================
enum Mode : uint8_t { MODE_AIR = 0, MODE_SKIN = 1 };
enum AdjustTarget : uint8_t { ADJ_TEMP = 0, ADJ_HUM = 1 };

inline void drawOledC(Adafruit_SSD1306 &oledC, uint8_t ch,
                      Mode mode, AdjustTarget target,
                      float spAir, float spSkin, float spHum){
  TcaBus::selectSettle(ch);
  oledC.clearDisplay();
  oledC.setTextColor(SSD1306_WHITE);

  // Título simple
  oledC.setTextSize(1);
  oledC.setCursor(0, 0);
  if (target == ADJ_TEMP) {
    oledC.println(mode == MODE_AIR ? F("SET TEMP: AIR") : F("SET TEMP: SKIN"));
  } else {
    oledC.println(F("SET HUMIDITY"));
  }

  // Línea divisoria
  for (int x = 0; x < 128; x++) oledC.drawPixel(x, 14, SSD1306_WHITE);

  // Valor grande
  oledC.setTextSize(3);
  oledC.setCursor(12, 28);
  char b[8];
  if (target == ADJ_TEMP) {
    float val = (mode == MODE_AIR) ? spAir : spSkin;
    snprintf(b, sizeof(b), "%.1f", val);
    oledC.print(b);
    oledC.setTextSize(1); oledC.print(" C");
  } else {
    snprintf(b, sizeof(b), "%.1f", spHum);
    oledC.print(b);
    oledC.setTextSize(1); oledC.print(" %");
  }

  oledC.display();
}

