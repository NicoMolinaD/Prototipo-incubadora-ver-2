#pragma once
#include <Adafruit_SHT4x.h>
#include "TcaBus.h"

struct AirReading { float tC=NAN, rh=NAN; bool ok=false; };

class SHT41Muxed {
  Adafruit_SHT4x dev_;
  uint8_t ch_;
public:
  SHT41Muxed(uint8_t ch): ch_(ch) {}
  bool begin() {
    TcaBus::select(ch_);
    if (!dev_.begin()) return false;
    dev_.setPrecision(SHT4X_HIGH_PRECISION);
    dev_.setHeater(SHT4X_NO_HEATER);
    return true;
  }
  AirReading read() {
    TcaBus::select(ch_);
    sensors_event_t hum, temp;
    bool ok = dev_.getEvent(&hum,&temp);
    AirReading r; r.ok=ok;
    if (ok){ r.tC=temp.temperature; r.rh=hum.relative_humidity; }
    return r;
  }
};
