#pragma once
#ifdef USE_BLE_COMM

// Si otra lib definió "Advertise" como macro (DFPlayer), la quitamos:
#ifdef Advertise
#undef Advertise
#endif

#include <NimBLEDevice.h>
#include "Alarms.h"
#include "Telemetry.h"  // <- nuevo header compartido

class CommBLE {
  NimBLEServer *srv_=nullptr; NimBLECharacteristic *ch_=nullptr;
public:
  void begin(){
    NimBLEDevice::init("Incubadora S3");
    srv_ = NimBLEDevice::createServer();
    auto svc = srv_->createService("6E400001-B5A3-F393-E0A9-E50E24DCCA9E");
    ch_ = svc->createCharacteristic("6E400003-B5A3-F393-E0A9-E50E24DCCA9E",
                                    NIMBLE_PROPERTY::NOTIFY);
    svc->start();
    auto adv = NimBLEDevice::getAdvertising();
    adv->addServiceUUID(svc->getUUID()); adv->start();
  }
  void send(const TelemetryPacket &p){
    if (!ch_) return;
    ch_->setValue((uint8_t*)&p, sizeof(p)); ch_->notify();
  }
};
#endif
