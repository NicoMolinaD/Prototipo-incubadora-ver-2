#pragma once
#include <Arduino.h>
#include <HardwareSerial.h>
#include <DFRobotDFPlayerMini.h>
#include "Config.h"

enum AlertTrack : uint16_t {
  AT_OVERTEMP        = MP3_OVERTEMP,
  AT_AIRFLOW_FAIL    = MP3_AIRFLOW_FAIL,
  AT_SENSOR_FAIL     = MP3_SENSOR_FAIL,
  AT_PROGRAM_FAIL    = MP3_PROGRAM_FAIL,
  AT_BAD_POSTURE     = MP3_BAD_POSTURE
};

class DFPlayerMiniSvc {
  HardwareSerial serial_;
  DFRobotDFPlayerMini df_;
  bool ready_ = false;
  bool muted_ = false;
  int  volDefault_ = 25;
  int  volSaved_   = 25;
  unsigned long lastPlayMs_ = 0;
  const unsigned long PLAY_COOLDOWN_MS = 2500;
public:
  DFPlayerMiniSvc() : serial_(DFPLAYER_UART_NUM) {}
  bool begin(int volDefault = 25) {
    volDefault_ = constrain(volDefault, 0, 30);
    serial_.begin(9600, SERIAL_8N1, DFPLAYER_PIN_RX, DFPLAYER_PIN_TX);
    delay(200);
    for (int i=0; i<8 && !ready_; ++i) {
      ready_ = df_.begin(serial_, true, true);
      if (!ready_) delay(300);
    }
    if (!ready_) ready_ = df_.begin(serial_);
    if (!ready_) return false;
    df_.volume(volDefault_); df_.EQ(DFPLAYER_EQ_NORMAL);
    volSaved_=volDefault_; muted_=false; return true;
  }
  void poll() { if (ready_ && df_.available()) { (void)df_.readType(); (void)df_.read(); } }
  void setVolume(uint8_t v){ if(!ready_) return; v=constrain(v,0,30); df_.volume(v); if(!muted_) volSaved_=v; }
  void setMute(bool on){ if(!ready_) return; if(on){ volSaved_=df_.readVolume(); df_.volume(0); muted_=true; } else { df_.volume(volSaved_<=0?volDefault_:volSaved_); muted_=false; } }
  bool isReady() const { return ready_; }
  void playTrack(uint16_t n){ if(!ready_) return; unsigned long now=millis(); if(now-lastPlayMs_<PLAY_COOLDOWN_MS) return; lastPlayMs_=now; df_.playMp3Folder(n); }
  void playAlert(AlertTrack at){ playTrack((uint16_t)at); }
};
