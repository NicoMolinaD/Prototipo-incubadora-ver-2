#pragma once
#include <Arduino.h>

// ===== I2C / TCA9548A =====
#define I2C_SDA             1
#define I2C_SCL             2
#define TCA_ADDR            0x70

// TCA channels
#define CH_SHT41_A          6   // air1
#define CH_SHT41_B          7   // air2
#define CH_SHT41_C          5   // air3 extra
#define CH_SHT41_D          0   // extra/skin por SHT si lo usas
#define CH_LTR390           1   // reemplaza SHT31
#define CH_OLED_A           4
#define CH_OLED_B           3
#define CH_OLED_C           2

// ===== TRIAC / ZC (reubicado por keypad) =====
#define ZC_PIN              7
#define TRIAC_PIN           15
#define HALF_CYCLE_US       8333UL  // 60 Hz

// ===== HX711 (libre GPIO4 para NTC) =====
#define HX711_DOUT          6
#define HX711_SCK           5

// ===== Sensores / Actuadores =====
#define AIRFLOW_PIN         3       // 1=OK, 0=falla
#define HUM_PWM_PIN         8       // PWM humidificador (PID LEDC)

// ===== DFPlayer (UART1) =====
#define DFPLAYER_UART_NUM   1
#define DFPLAYER_PIN_TX     17  // ESP32->DFPlayer RX
#define DFPLAYER_PIN_RX     16  // DFPlayer TX->ESP32

// ===== ESP-NOW =====
#define ESPNOW_CHANNEL      6
static uint8_t CAM_PEER_MAC[6] = {0x24,0x6F,0x28,0x00,0x00,0x01};

// ===== UI / Setpoints =====
enum Mode : uint8_t { MODE_AIR=0, MODE_SKIN=1 };
static constexpr float AIR_MIN=25.0f, AIR_MAX=40.0f;
static constexpr float SKIN_MIN=30.0f, SKIN_MAX=37.0f;
#define UI_SAMPLE_MS        500

// ===== Control Proporcional (temperatura) =====
#define KP_DEFAULT          50.0f
#define SETPOINT_AIR_DEF    35.0f
#define SETPOINT_SKIN_DEF   34.0f

// ===== Watchdog =====
#define WDT_TIMEOUT_S       6

// ===== Comunicación (elige 1) =====
#define USE_BLE_COMM
// #define USE_WIFI_COMM

// ===== Alertas → DFPlayer map =====
#define MP3_OVERTEMP        1
#define MP3_AIRFLOW_FAIL    2
#define MP3_SENSOR_FAIL     3
#define MP3_PROGRAM_FAIL    4
#define MP3_BAD_POSTURE     5

// ===== NeoPixel =====
#define LED_PIN             18
#define LED_COUNT           90

// ===== NTC (piel) en ADC GPIO4 =====
#define NTC_PIN             4
#define NTC_R_SERIES        10000.0f   // 10k en serie
#define NTC_R0              10000.0f   // 10k @25°C
#define NTC_BETA            3950.0f
#define NTC_T0_K            298.15f    // 25°C en Kelvin
