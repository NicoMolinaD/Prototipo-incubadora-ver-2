#pragma once
#include <HX711_ADC.h>
#include <EEPROM.h>
#include "Config.h"

class WeightScaleHX711 {
  HX711_ADC lc_;
  bool eepromInit_=false;
  float calFactor_=1.0f;
  long tareOffset_=0;
public:
  WeightScaleHX711(): lc_(HX711_DOUT, HX711_SCK) {}
  void eepromBeginIf(){ if(!eepromInit_){ EEPROM.begin(512); eepromInit_=true; } }
  void begin() {
    lc_.begin(); lc_.start(2500, true);
    while(!lc_.update()) delay(2);
    if(!loadCal()){ lc_.setCalFactor(1.0f); }
  }
  bool loadCal() {
    eepromBeginIf(); float cf; long to; EEPROM.get(0, cf); EEPROM.get(8, to);
    if (isnan(cf) || cf==0.0f || fabs(cf)>1e5) return false;
    calFactor_=cf; tareOffset_=to; lc_.setCalFactor(calFactor_); if (tareOffset_!=0) lc_.setTareOffset(tareOffset_);
    return true;
  }
  void saveCal() { eepromBeginIf(); EEPROM.put(0, calFactor_); EEPROM.put(8, lc_.getTareOffset()); EEPROM.commit(); }
  void tare() { lc_.tareNoDelay(); while(!lc_.getTareStatus()){ lc_.update(); delay(5);} tareOffset_=lc_.getTareOffset(); saveCal(); }
  float readKg(uint8_t N=13){
    N = max<uint8_t>(N,7); float v[32]; uint8_t k=min<uint8_t>(N,32);
    for(uint8_t i=0;i<k;i++){ while(!lc_.update()) delay(2); v[i]=lc_.getData(); }
    for(uint8_t i=1;i<k;i++){ float key=v[i]; int j=i-1; while(j>=0 && v[j]>key){ v[j+1]=v[j]; j--; } v[j+1]=key; }
    uint8_t a=k/5, b=k-a; double s=0; uint8_t m=0; for(uint8_t i=a;i<b;i++){ s+=v[i]; m++; }
    return (m? (float)(s/m): v[k/2]);
  }
  HX711_ADC& raw(){return lc_;}
};
