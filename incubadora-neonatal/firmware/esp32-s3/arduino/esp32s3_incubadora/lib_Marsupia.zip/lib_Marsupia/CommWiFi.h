#pragma once
#ifdef USE_WIFI_COMM
#include <WiFi.h>
#include <WiFiUdp.h>
#include "Alarms.h"
#include "Telemetry.h"  // <- nuevo header compartido

class CommWiFi {
  WiFiUDP udp_;
public:
  void begin(){
    WiFi.mode(WIFI_STA);
    WiFi.begin("SSID_AJUSTA","PASS_AJUSTA");
    unsigned long t=millis();
    while(WiFi.status()!=WL_CONNECTED && millis()-t<10000) delay(100);
    udp_.begin(5005);
  }
  void send(const TelemetryPacket &p){
    IPAddress bcast = ~WiFi.subnetMask() | WiFi.gatewayIP();
    udp_.beginPacket(bcast, 5005);
    udp_.write((const uint8_t*)&p, sizeof(p));
    udp_.endPacket();
  }
};
#endif
