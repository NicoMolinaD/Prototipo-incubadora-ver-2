#pragma once
#include "Config.h"
#include <WiFi.h>
#include <esp_now.h>

class EspNowCam {
public:
  volatile uint8_t lastCode = 0;

  // Nueva firma: info + data + len
  static void onRecv(const esp_now_recv_info* info, const uint8_t *data, int len){
    (void)info; // no lo usamos por ahora
    if (len >= 1 && data) instance().lastCode = data[0];
  }

  static EspNowCam& instance(){ static EspNowCam inst; return inst; }

  bool begin(){
    WiFi.mode(WIFI_STA);
    if (esp_now_init()!=ESP_OK) return false;
    esp_now_register_recv_cb(EspNowCam::onRecv);

    esp_now_peer_info_t p = {};
    memcpy(p.peer_addr, CAM_PEER_MAC, 6);
    p.channel = ESPNOW_CHANNEL;
    p.encrypt = false;
    esp_now_add_peer(&p);
    return true;
  }
};

