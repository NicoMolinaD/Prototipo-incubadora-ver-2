#pragma once
#include <Arduino.h>

// Columnas: C1..C5 -> 39,38,37,36,35
// Filas:    F1=41, F2=40
// Devuelve bitmask de teclas presionadas (bit = r*5+c)
struct Keypad25 {
  const int cols[5] = {39,38,37,36,35};
  const int rows[2] = {41,40};

  void begin(){
    for (int c: cols){ pinMode(c, INPUT_PULLUP); }
    for (int r: rows){ pinMode(r, INPUT); }
  }

  uint16_t scanPressedMask(){
    uint16_t mask = 0;
    for (int r=0; r<2; r++){
      for (int i=0;i<2;i++){
        if (i==r){ pinMode(rows[i], OUTPUT); digitalWrite(rows[i], LOW); }
        else      pinMode(rows[i], INPUT);
      }
      delayMicroseconds(60);
      for (int c=0; c<5; c++){
        if (digitalRead(cols[c]) == LOW) mask |= (1u << (r*5 + c));
      }
    }
    for (int i=0;i<2;i++){ pinMode(rows[i], OUTPUT); digitalWrite(rows[i], LOW); }
    return mask;
  }

  static inline bool has(uint16_t mask, int r, int c){ return mask & (1u << (r*5 + c)); }
};
