#pragma once
#include <Adafruit_NeoPixel.h>
#include "Config.h"

enum LightMode : uint8_t { LM_CIRCADIAN=0, LM_ICTERICIA=1, LM_PBM=2 };

class LightController {
  Adafruit_NeoPixel strip_;
  LightMode mode_ = LM_CIRCADIAN;
  const unsigned long DAY_DURATION_MS = 300000; // 5 min demo
  unsigned long t0_=0;
public:
  LightController(): strip_(LED_COUNT, LED_PIN, NEO_GRBW + NEO_KHZ800) {}
  void begin(){ strip_.begin(); strip_.setBrightness(150); strip_.show(); t0_=millis(); }
  void setMode(LightMode m){ mode_=m; }
  void update(){
    switch(mode_){ case LM_CIRCADIAN: renderCircadian(); break;
                   case LM_ICTERICIA: renderIctericia(); break;
                   case LM_PBM:       renderPBM(); break; }
    strip_.show();
  }
private:
  void renderCircadian(){
    const float A=0.0, B=0.25, C=0.5, D=0.75, E=0.95;
    unsigned long tic = millis() % DAY_DURATION_MS;
    float p = (float)tic / DAY_DURATION_MS;
    uint8_t r=0,g=0,b=0,ww=0,cw=0;
    if (p>=A && p<B){ float t=(p-A)/(B-A); r=lerp(255,0,t); g=lerp(60,0,t); ww=lerp(0,255,t);
    } else if (p>=B && p<C){ float t=(p-B)/(C-B); ww=lerp(255,0,t); cw=lerp(0,255,t);
    } else if (p>=C && p<D){ float t=(p-C)/(D-C); cw=lerp(255,0,t); ww=lerp(0,255,t);
    } else if (p>=D && p<E){ float t=(p-D)/(E-D); ww=lerp(255,0,t); r=lerp(0,255,t); g=lerp(0,60,t);
    } else { r=20; }
    setStripColor(r,g,b,ww,cw);
  }
  void renderIctericia(){ setStripColor(0,0,200,0,0); }
  void renderPBM(){ float s=0.5f*(1.0f + sinf((millis()-t0_)/1000.0f)); uint8_t r=(uint8_t)(80+175*s); setStripColor(r,0,0,0,0); }
  static uint8_t lerp(uint8_t a, uint8_t b, float t){ return a + (b-a)*t; }
  void setStripColor(uint8_t r,uint8_t g,uint8_t b,uint8_t ww,uint8_t cw){
    for (uint16_t i=0; i<strip_.numPixels(); i++){
      if (i % 2 == 0) strip_.setPixelColor(i, strip_.Color(r,g,b,ww));
      else            strip_.setPixelColor(i, strip_.Color(r,g,b,cw));
    }
  }
};
