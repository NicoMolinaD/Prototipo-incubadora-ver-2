#pragma once
#include <Arduino.h>

struct TelemetryPacket {
  float tAir;
  float tSkin;
  float rh;
  float kg;
  uint8_t alerts;
} __attribute__((packed));
